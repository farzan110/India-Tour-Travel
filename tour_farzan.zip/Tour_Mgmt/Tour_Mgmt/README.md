# Tour_Management_Project
 simple asp.net application for booking of tours.
 
# Admin
* Add Tour
* Manage Tour 
* See Bookings
<img width="752" alt="image" src="https://user-images.githubusercontent.com/81226571/196478877-2a66ec3b-1a71-48ce-ab20-6013890ae19d.png">
<img width="760" alt="image" src="https://user-images.githubusercontent.com/81226571/196479030-a0cbc14c-6085-4d7c-8de5-86414aa8be7f.png">

# User
- Manage Profile
- Book Tour
- See his booking
<img width="745" alt="image" src="https://user-images.githubusercontent.com/81226571/196478761-6a7d261a-1769-4c56-9052-b3e4a77722e5.png">

## How to run?
- Fork Project 
- clone repository( git clone https://github.com/jaygajera17/Tour_Management_Asp.Net)
- open app_data folder
- right click on database file (.mdf) click modify connection.
- you can also config your own database by step mention in [database.txt](https://github.com/jaygajera17/Tour_Management_Asp.Net/blob/main/Database.txt) file.

## Important Links
- 𝗬𝗼𝘂𝘁𝘂𝗯𝗲 𝗽𝗿𝗼𝗷𝗲𝗰𝘁 𝘃𝗶𝗱𝗲𝗼 𝗪𝗼𝗿𝗸𝗶𝗻𝗴 𝗗𝗲𝗺𝗼  ::---  [  click here  ](https://youtu.be/r-UfxsVzndk) [![youtube][youtube-shield]][youtube-url]


[youtube-shield]:https://img.shields.io/youtube/views/r-UfxsVzndk?style=social
[youtube-url]:  https://youtu.be/r-UfxsVzndk
